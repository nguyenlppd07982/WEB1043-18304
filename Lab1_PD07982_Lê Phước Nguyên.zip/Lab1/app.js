// Nhập a từ bàn phím
let a = prompt("Nhập số nguyên a:")

// Nhập b từ bàn phím
let b = prompt("Nhập số nguyên b:")

// Gắn c bằng a + b và ép kiểu a và b về số nguyên
let c = parseInt(a) + parseInt(b)

// In ra màn hình kết quả c
document.write("Kết quả a + b = ",c)

// Console.log ra kết quả c
console.log("Kết quả a + b = "+ c)